#opinion_annotations_de#
======================

Opinion annotations for German

##Hotel##
tag -> hotel: hotel set 1 and hotel set 2, final version (version 20140318/1.0)
kaf -> hotel: created with version 20143018/1.0

##news##
Tag and KAF files, processed with the pipeline:
  + polarity_tagger.sh --ignore-pos
  + ner_tagger.sh de
  + constituent_parser_de.sh

##attractions##
Tag and KAF files processed with:
  + ehu-nerc-de entity tagger
  + constituent parser (stanford)
  + polarity tagger
  + Manual annotations --> opinions and properties/features/aspects
