#opinion_annotations_nl#

##Hotel##
* Hotel set1 and set2

##Attraction##
* TAG and KAF files 
* Fixed headers
* Opinions and features obtained from annotations
* Dependencies order according to English

##Restaurant##
* TAG and KAF files
* Fixed headers
* Opinions and features obtained from manual annotations
* Dependencies order according to English definition

##News##
* TAG and KAF files
* Pipeline run with polarity tagger (general domain lexicon), constituent and dependency parser
* Stats on opinion density per sentence included
