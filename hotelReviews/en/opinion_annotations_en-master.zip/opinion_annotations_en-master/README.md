#opinion_annotations_en#

Opinion annotations for English

* tag/hotel: 18th-Mar-2014 added hotelset2

  18th-Mar-2014: only set 1

##News##
Added TAG and KAF files, final version