opinion_annotations_es
======================

Opinion annotations for Spanish

 hotel 18th-Mar-2014 --> set 1
 hotel 26th-Mar-2014 --> set 2
 set1 and set2 merged in hotel
