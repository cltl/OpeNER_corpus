opinion_annotations_fr
======================

Opinion annotations for French
Included
* hotel set 1 and set2 (TAG and KAF)
* attraction (TAG) after formal check and re-check (2014-04-03)
* attraction (KAF) after formal check and re-check (2014-04-03)

