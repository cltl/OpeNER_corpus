opinion_annotations_it
======================

Opinion annotations for Italian

tag -> hotel: includes hotel set1 and hotel set 2, final version
